<?php

namespace Drupal\Component\Serialization\Exception;

/**
 * Exception thrown when a data type is invalid.
 */
class InvalidDataTypeException extends \InvalidArgumentException {
}
